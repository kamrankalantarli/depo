from django.shortcuts import render , redirect,get_object_or_404,HttpResponseRedirect
from .models import Product
from  .forms import CommentaForm
def cart_home(request):
    queryset = Product.objects.all()
    context = {
        'object_list': queryset
    }
    return render(request,'book/index.html', context)
def post_detail(request , id):
    instace= get_object_or_404(Product,id=id)
    form = CommentaForm(request.POST or None)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.user = request.user
        comment.book = instace
        comment.save()
    context = {
        'form':form,
        'object': instace,
    }
    return render(request,"book/detail.html",context)
