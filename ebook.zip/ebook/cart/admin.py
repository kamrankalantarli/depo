from django.contrib import admin
from cart.models import Product,Comment

admin.site.register(Product)
admin.site.register(Comment)
