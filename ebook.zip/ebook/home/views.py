from django.shortcuts import render


def contactl(request):

    return render(request, "contact/index.html")